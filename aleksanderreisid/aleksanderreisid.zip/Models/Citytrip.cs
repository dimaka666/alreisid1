﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace aleksanderreisid.Models
{
    public class Citytrip
    {
        public int ID { get; set; }
        public int City { get; set; }
        public int Trip { get; set; }
    }
}